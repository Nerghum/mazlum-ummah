import { PageHeader } from '../components/PageHeader.jsx';
import { DashboardPage } from './DashboardPage.jsx';

export function AnalyticsPage() {
  return (
    <>
      <PageHeader title="Analytics" description="Daily views, weekly growth, monthly reporting, category performance, and country analytics." />
      <DashboardPage />
    </>
  );
}
