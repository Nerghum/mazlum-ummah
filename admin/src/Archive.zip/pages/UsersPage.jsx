import { Plus } from 'lucide-react';
import { useForm } from 'react-hook-form';
import { Button } from '../components/Button.jsx';
import { Card } from '../components/Card.jsx';
import { DataTable } from '../components/DataTable.jsx';
import { FormField } from '../components/FormField.jsx';
import { PageHeader } from '../components/PageHeader.jsx';
import { useApiResource } from '../hooks/useApiResource.js';
import { api } from '../services/api.js';

const roles = ['Super Admin', 'Admin', 'Editor', 'Journalist', 'Moderator'];

export function UsersPage() {
  const { data, loading, reload } = useApiResource('/users');
  const { register, handleSubmit, reset } = useForm({ defaultValues: { name: '', email: '', password: '', role: 'Journalist' } });
  async function save(values) {
    await api.post('/users', values);
    reset();
    reload();
  }
  return (
    <>
      <PageHeader title="Users" description="Manage newsroom users, roles, and RBAC access." />
      <div className="grid gap-5 lg:grid-cols-[380px_1fr]">
        <Card className="p-5">
          <form className="space-y-4" onSubmit={handleSubmit(save)}>
            <FormField label="Name"><input className="w-full rounded-lg border border-slate-200 px-3 py-2 dark:border-slate-700 dark:bg-slate-950" {...register('name')} /></FormField>
            <FormField label="Email"><input className="w-full rounded-lg border border-slate-200 px-3 py-2 dark:border-slate-700 dark:bg-slate-950" {...register('email')} /></FormField>
            <FormField label="Password"><input type="password" className="w-full rounded-lg border border-slate-200 px-3 py-2 dark:border-slate-700 dark:bg-slate-950" {...register('password')} /></FormField>
            <FormField label="Role"><select className="w-full rounded-lg border border-slate-200 px-3 py-2 dark:border-slate-700 dark:bg-slate-950" {...register('role')}>{roles.map((role) => <option key={role}>{role}</option>)}</select></FormField>
            <Button><Plus size={16} /> Add user</Button>
          </form>
        </Card>
        <DataTable loading={loading} rows={data} columns={[{ key: 'name', label: 'Name' }, { key: 'email', label: 'Email' }, { key: 'role', label: 'Role' }, { key: 'isActive', label: 'Active', render: (row) => row.isActive ? 'Yes' : 'No' }]} />
      </div>
    </>
  );
}
