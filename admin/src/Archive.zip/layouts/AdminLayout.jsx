import { BadgeDollarSign, BarChart3, BookOpenText, FileText, HelpCircle, Home, Images, LayoutDashboard, LogOut, Megaphone, Menu, MessageSquareText, Moon, Settings, Sun, Users } from 'lucide-react';
import { NavLink, Outlet, useNavigate } from 'react-router-dom';
import { useDispatch, useSelector } from 'react-redux';
import { logout } from '../store/authSlice.js';
import { hideToast, toggleTheme } from '../store/uiSlice.js';
import { classNames } from '../utils/format.js';

const navItems = [
  { to: '/dashboard', label: 'Dashboard', icon: LayoutDashboard },
  { to: '/news', label: 'News', icon: FileText, children: [{ to: '/news-categories', label: 'Categories' }] },
  { to: '/blogs', label: 'Blogs', icon: BookOpenText, children: [{ to: '/blog-categories', label: 'Categories' }] },
  { to: '/media-achievements', label: 'Media Achievements', icon: Images },
  { to: '/social-posts', label: 'Social Posts', icon: MessageSquareText },
  { to: '/notices', label: 'Notices', icon: Megaphone },
  { to: '/advertisements', label: 'Ads Management', icon: BadgeDollarSign },
  { to: '/media', label: 'Media Library', icon: Images },
  { to: '/homepage', label: 'Homepage Builder', icon: Home },
  { to: '/menus', label: 'Header Menu', icon: Menu },
  { to: '/faqs', label: 'FAQs', icon: HelpCircle },
  { to: '/analytics', label: 'Analytics', icon: BarChart3 },
  { to: '/users', label: 'Users', icon: Users },
  { to: '/settings', label: 'Settings', icon: Settings }
];

export function AdminLayout() {
  const dispatch = useDispatch();
  const navigate = useNavigate();
  const { user } = useSelector((state) => state.auth);
  const { darkMode, toast } = useSelector((state) => state.ui);

  return (
    <div className={classNames('min-h-screen', darkMode && 'dark')}>
      <div className="flex min-h-screen bg-slate-50 dark:bg-slate-950">
        <aside className="no-print fixed inset-y-0 left-0 z-20 hidden w-72 border-r border-slate-200 bg-white px-4 py-5 dark:border-slate-800 dark:bg-slate-900 lg:block">
          <div className="mb-8 px-3">
            <div className="text-xl font-bold text-slate-950 dark:text-white">Newsroom CMS</div>
            <div className="text-sm text-slate-500">TailAdmin Console</div>
          </div>
          <nav className="space-y-1">
            {navItems.map((item) => (
              <div key={item.to}>
                <NavLink
                  to={item.to}
                  className={({ isActive }) =>
                    classNames(
                      'flex items-center gap-3 rounded-lg px-3 py-2.5 text-sm font-medium transition',
                      isActive ? 'bg-brand-50 text-brand-700 dark:bg-brand-500/10 dark:text-brand-100' : 'text-slate-600 hover:bg-slate-100 dark:text-slate-300 dark:hover:bg-slate-800'
                    )
                  }
                >
                  <item.icon size={18} />
                  {item.label}
                </NavLink>
                {item.children && (
                  <div className="mt-1 ml-6 space-y-1 border-l border-slate-200 pl-3 dark:border-slate-800">
                    {item.children.map(child => (
                      <NavLink
                        key={child.to}
                        to={child.to}
                        className={({ isActive }) =>
                          classNames(
                            'block rounded-lg px-3 py-2 text-sm font-medium transition',
                            isActive ? 'bg-brand-50 text-brand-700 dark:bg-brand-500/10 dark:text-brand-100' : 'text-slate-600 hover:bg-slate-100 dark:text-slate-300 dark:hover:bg-slate-800'
                          )
                        }
                      >
                        {child.label}
                      </NavLink>
                    ))}
                  </div>
                )}
              </div>
            ))}
          </nav>
        </aside>
        <main className="flex min-h-screen flex-1 flex-col lg:pl-72">
          <header className="no-print sticky top-0 z-10 flex h-16 items-center justify-between border-b border-slate-200 bg-white/90 px-4 backdrop-blur dark:border-slate-800 dark:bg-slate-900/90">
            <div>
              <div className="text-sm text-slate-500">Welcome back</div>
              <div className="font-semibold">{user?.name || 'Editor'}</div>
            </div>
            <div className="flex items-center gap-2">
              <button className="rounded-lg border border-slate-200 p-2 dark:border-slate-700" onClick={() => dispatch(toggleTheme())} aria-label="Toggle theme">
                {darkMode ? <Sun size={18} /> : <Moon size={18} />}
              </button>
              <button
                className="rounded-lg border border-slate-200 p-2 text-red-600 dark:border-slate-700"
                onClick={() => {
                  dispatch(logout());
                  navigate('/login');
                }}
                aria-label="Logout"
              >
                <LogOut size={18} />
              </button>
            </div>
          </header>
          <section className="flex-1 p-4 sm:p-6 lg:p-8">
            <Outlet />
          </section>
        </main>
      </div>
      {toast && (
        <button onClick={() => dispatch(hideToast())} className="fixed right-5 top-5 z-50 rounded-lg bg-slate-950 px-4 py-3 text-sm text-white shadow-soft dark:bg-white dark:text-slate-950">
          {toast}
        </button>
      )}
    </div>
  );
}
