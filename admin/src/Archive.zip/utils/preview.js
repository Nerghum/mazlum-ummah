const FRONTEND_URL = (import.meta.env.VITE_FRONTEND_URL || 'http://localhost:3000').replace(/\/$/, '');

export function newsPreviewUrl(news) {
  if (!news?.slug) return '';
  const categorySlug = news.mainCategory?.slug || 'general';
  return `${FRONTEND_URL}/news/${categorySlug}/${news.slug}`;
}

export function blogPreviewUrl(blog) {
  if (!blog?.slug) return '';
  return `${FRONTEND_URL}/blogs/${blog.slug}`;
}

export function mediaAchievementPreviewUrl(item) {
  if (!item?.slug) return '';
  return `${FRONTEND_URL}/media-achievements/${item.slug}`;
}
